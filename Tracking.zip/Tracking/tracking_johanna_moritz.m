%% from David from main_tracking

clear all; clc; close all;

%% loading data
% Load either top or bottom. There are variable name collisions in the two
% files, so loading both will overwrite some variables.
%load('../data/sfm_top.mat');
load('centers_precomputed');

%% extract variables
% This section is not really necessary. It simply transforms the data into
% another representation to simplify access for the tracking.
all_centers_top_Area = cell(length(all_centers_top), 1);
all_centers_top_Centroid = cell(length(all_centers_top), 1);
all_centers_top_BoundingBox = cell(length(all_centers_top), 1);

for useId = 1:length(all_centers_top)
    if isempty(all_centers_top{useId})
        all_centers_top_Area{useId} = [];
        all_centers_top_Centroid{useId} = [];
        all_centers_top_BoundingBox{useId} = [];
   else
       all_centers_top_Area{useId} = cell2mat({all_centers_top{useId}.Area}');
       all_centers_top_Centroid{useId} = cell2mat({all_centers_top{useId}.Centroid}');
       all_centers_top_BoundingBox{useId} = cell2mat({all_centers_top{useId}.BoundingBox}');
    end
end

all_centers_bottom_Area = cell(length(all_centers_bottom), 1);
all_centers_bottom_Centroid = cell(length(all_centers_bottom), 1);
all_centers_bottom_BoundingBox = cell(length(all_centers_bottom), 1);

for useId = 1:length(all_centers_bottom)
    if isempty(all_centers_bottom{useId})
        all_centers_bottom_Area{useId} = [];
        all_centers_bottom_Centroid{useId} = [];
        all_centers_bottom_BoundingBox{useId} = [];
   else
       all_centers_bottom_Area{useId} = cell2mat({all_centers_bottom{useId}.Area}');
       all_centers_bottom_Centroid{useId} = cell2mat({all_centers_bottom{useId}.Centroid}');
       all_centers_bottom_BoundingBox{useId} = cell2mat({all_centers_bottom{useId}.BoundingBox}');
    end
end

%%  tracking part

cameraParams_RGB = load('./data/camParams_RGB.mat');
camPoses_top_RGB = load('./data/sfm_top.mat');
camPoses_bottom_RGB = load('./data/sfm_bottom.mat');

camPoses_top = camPoses_top_RGB.vSet.Views;
camPoses_bottom = camPoses_bottom_RGB.vSet.Views;
cameraParams = cameraParams_RGB.cameraParams;

xyzPoints_top = camPoses_top_RGB.xyzPoints;
xyzPoints_bottom = camPoses_bottom_RGB.xyzPoints;

imgscale = 1;
intrinsics = cameraIntrinsics(cameraParams.FocalLength*imgscale,cameraParams.PrincipalPoint*imgscale,cameraParams.ImageSize*imgscale);

k_class_top = 20000;
k_class_bottom = 20000;

threshold_top = 10;
threshold_bottom = 35;

[result_top, count_top] = tracking(intrinsics, camPoses_top, xyzPoints_top, all_centers_top_Centroid, threshold_top, k_class_top, all_centers_top_BoundingBox)
[result_bottom, count_bottom] = tracking(intrinsics, camPoses_bottom, xyzPoints_bottom, all_centers_bottom_Centroid, threshold_bottom, k_class_bottom, all_centers_bottom_BoundingBox)


%% Visualize results for top 

close all;
data.camParams_RGB = load('./data/camParams_RGB.mat');

for t = 1:19
% loading data
    useIdTop = 20 - t;
    
    data.peaches.top.RGB.path = './data/peaches/top/RGB';

    data.peaches.top.RGB.ds = datastore(data.peaches.top.RGB.path);

    data.peaches.top.RGB.original = readimage(data.peaches.top.RGB.ds, useIdTop);

    % undistortion
    data.peaches.top.RGB.undistorted = undistort(data.peaches.top.RGB.original, data.camParams_RGB.cameraParams);

    % display images (for testing)

    figure(useIdTop);
    imshow(data.peaches.top.RGB.undistorted); title ('tracking'); hold on;
    for k = 1 : size(all_centers_top_Centroid{useIdTop},1)
        thisBB = all_centers_top_BoundingBox{useIdTop}(k,:);
        rectangle('Position',[thisBB(1),thisBB(2),thisBB(3),thisBB(4)],'EdgeColor','b','LineWidth',1 );
    end
    for k=1 : size(result_top{useIdTop},1)
        plot(result_top{useIdTop}(k,1), result_top{useIdTop}(k,2), 'b*', 'LineWidth', 3, 'MarkerSize', 10);
    end
end

%% Visualize results for bottom 

close all;
data.camParams_RGB = load('./data/camParams_RGB.mat');

for t = 1:14 %wrong naming for all
% loading data
    useIdTop = 15 - t;
    
    data.peaches.top.RGB.path = './data/peaches/bottom/RGB';

    data.peaches.top.RGB.ds = datastore(data.peaches.top.RGB.path);

    data.peaches.top.RGB.original = readimage(data.peaches.top.RGB.ds, useIdTop);

    % undistortion
    data.peaches.top.RGB.undistorted = undistort(data.peaches.top.RGB.original, data.camParams_RGB.cameraParams);

    % display images (for testing)

    figure(useIdTop);
    imshow(data.peaches.top.RGB.undistorted); title ('tracking'); hold on;
    for k = 1 : size(all_centers_bottom_Centroid{useIdTop},1)
        thisBB = all_centers_bottom_BoundingBox{useIdTop}(k,:);
        rectangle('Position',[thisBB(1),thisBB(2),thisBB(3),thisBB(4)],'EdgeColor','b','LineWidth',1 );
    end
    for k=1 : size(result_bottom{useIdTop},1)
        plot(result_bottom{useIdTop}(k,1), result_bottom{useIdTop}(k,2), 'b*', 'LineWidth', 3, 'MarkerSize', 10);
    end
end